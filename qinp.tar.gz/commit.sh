git commit -am "Message"
git push